<?php
require($_SERVER['DOCUMENT_ROOT'] . '/bitrix/header.php');
$APPLICATION->SetTitle('1C-Bitrix');
?>

<main id="main-content">
<!-- Page Hero -->
<section class="page-hero">
  <div class="container">
    <h1 class="page-hero__title">Веб-системы на платформе «1С-Битрикс»</h1>
    <p class="page-hero__subtitle">Профессиональная система управления сайтами и интернет-магазинами. Самая популярная коммерческая CMS в России. Создаём корпоративные сайты, интернет-магазины, B2B-порталы и личные кабинеты с интеграцией с 1С и соответствием законодательству.</p>
    <div style="margin-top:24px;">
      <a href="/project/" class="btn btn-accent">Обсудить проект</a>
    </div>
  </div>
</section>

<!-- Какие продукты создаются -->
<section class="section">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Какие продукты создаются</h2>
    </div>
    <div class="solution-grid grid grid--3">
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">🏢</div>
        <h3 class="solution-card__title">Корпоративные сайты</h3>
        <p class="solution-card__desc">Представление компании, продуктов, компетенций и проектов.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">🛒</div>
        <h3 class="solution-card__title">Интернет-магазины</h3>
        <p class="solution-card__desc">Каталоги, цены, остатки, заказы, оплаты и доставка.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">🤝</div>
        <h3 class="solution-card__title">B2B-порталы</h3>
        <p class="solution-card__desc">Персональные условия, заказы, документы и работа с партнёрами.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">👤</div>
        <h3 class="solution-card__title">Личные кабинеты</h3>
        <p class="solution-card__desc">История взаимодействия, заявки, документы и статусы.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">📦</div>
        <h3 class="solution-card__title">Каталоги</h3>
        <p class="solution-card__desc">Структурированные каталоги с фильтрацией и обменом с 1С.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">📄</div>
        <h3 class="solution-card__title">Информационные сервисы</h3>
        <p class="solution-card__desc">Порталы знаний, базы данных, внутренние ресурсы компании.</p>
      </div>
    </div>
  </div>
</section>

<!-- Почему выбирают 1С-Битрикс -->
<section class="section section--alt">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Почему выбирают 1С-Битрикс</h2>
    </div>
    <div class="grid grid--3">
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">🔗</div>
        <h3 class="solution-card__title">Интеграция с 1С</h3>
        <p class="solution-card__desc">Двусторонний обмен данными в реальном времени. Синхронизация каталогов, остатков, цен и заказов.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">⚡</div>
        <h3 class="solution-card__title">Скорость и надёжность</h3>
        <p class="solution-card__desc">Запатентованная технология кеширования, облачные хранилища, распределение нагрузки.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">🔒</div>
        <h3 class="solution-card__title">Безопасность</h3>
        <p class="solution-card__desc">Многоуровневая защита от атак, контроль доступа, аудит действий пользователей.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">📜</div>
        <h3 class="solution-card__title">Соответствие законодательству</h3>
        <p class="solution-card__desc">Поддержка ФЗ-54 (онлайн-кассы), ФЗ-152 (персональные данные), готовое соглашение об обработке ПД.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">🌐</div>
        <h3 class="solution-card__title">Многосайтовость</h3>
        <p class="solution-card__desc">Несколько сайтов на одной лицензии, неограниченное количество лендингов в конструкторе.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <div class="solution-card__icon">🛠️</div>
        <h3 class="solution-card__title">Быстрый старт</h3>
        <p class="solution-card__desc">Маркетплейс готовых решений, удобный редактор лендингов, 200+ готовых блоков.</p>
      </div>
    </div>
  </div>
</section>

<!-- Интеграции -->
<section class="section section--alt">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Интеграции</h2>
      <p class="section-heading__subtitle" style="max-width:640px;margin:12px auto 0;">Веб-система на 1С-Битрикс работает эффективнее, когда связана с остальными сервисами</p>
    </div>
    <div class="animate-on-scroll" style="max-width:720px;margin:0 auto;">
      <ul style="list-style:none;padding:0;margin:0;display:grid;gap:12px;">
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--accent);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">С 1С — двусторонний обмен каталогами, остатками, ценами и заказами</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--accent);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">С Битрикс24 — передача обращений из сайта в CRM</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--accent);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">С платёжными системами — ЮKassa, Robokassa и другие</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--accent);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">Со службами доставки — СДЭК, Boxberry и другие</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--accent);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">С маркетплейсами — синхронизация заказов и остатков</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--accent);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">С внешними API — гибкая интеграция с любыми системами</li>
      </ul>
    </div>
  </div>
</section>

<!-- Возможности для интернет-магазинов -->
<section class="section">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Возможности для интернет-магазинов</h2>
    </div>
    <div class="solution-card animate-on-scroll" style="max-width:800px;margin:0 auto;">
      <div class="grid grid--2" style="margin-bottom:24px;">
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">Профессиональное управление</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">SKU, диапазоны цен, заказы, доставка, скидки, сравнение товаров, остатки на складе, импорт/экспорт, мультивалютность, аналитика продаж.</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">Адаптивный дизайн</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Адаптация под экраны любых устройств, сенсорные экраны, удобная навигация для покупателей.</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">Продающие лендинги</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Конструктор страниц, встроенная статистика, онлайн-консультант, CRM-формы заказа.</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">Готовые интеграции</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">1С, CRM, платёжные системы (ЮKassa, Robokassa), службы доставки (СДЭК, Boxberry).</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">E-mail маркетинг</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Триггерные рассылки, автоматизация, аналитика эффективности кампаний.</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">Соответствие законодательству</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Поддержка онлайн-касс (ФЗ-54), печать чеков, согласие на обработку ПД (ФЗ-152).</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Работа с существующими проектами -->
<section class="section">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Работа с существующими проектами</h2>
    </div>
    <div class="problem-grid">
      <div class="problem-card animate-on-scroll">аудит</div>
      <div class="problem-card animate-on-scroll">модернизация</div>
      <div class="problem-card animate-on-scroll">развитие</div>
      <div class="problem-card animate-on-scroll">обновление</div>
      <div class="problem-card animate-on-scroll">оптимизация</div>
      <div class="problem-card animate-on-scroll">перенос</div>
      <div class="problem-card animate-on-scroll">сопровождение</div>
    </div>
  </div>
</section>

<!-- Возможности для корпоративных сайтов -->
<section class="section section--alt">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Возможности для корпоративных сайтов</h2>
    </div>
    <div class="solution-card animate-on-scroll" style="max-width:800px;margin:0 auto;">
      <div class="grid grid--2">
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">Простое управление</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Конструктор «по месту», 200+ готовых блоков для создания страниц без программирования.</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">Личный кабинет клиента</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Повторение заказов, статус заявок, внутренний счёт, история взаимодействий.</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">Интерактивные сервисы</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Опросы, голосования, формы обратной связи, сегментация посетителей.</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">Коммуникации с клиентами</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Чат, социальные сети, мессенджеры, интеграция с CRM для учёта обращений.</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">E-mail рассылки</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Подписка на новости, сегментация аудитории, автоматизация рассылкок.</p>
        </div>
        <div style="padding:16px;background:var(--bg);border-radius:var(--card-radius);">
          <h4 style="font-size:1rem;margin-bottom:8px;">SEO-оптимизация</h4>
          <p style="font-size:0.9375rem;color:var(--text-light);margin:0;">Человеко-понятные адреса, уникальные мета-теги, управление страницей 404.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Производительность и стабильность -->
<section class="section section--alt">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Производительность и стабильность</h2>
    </div>
    <div class="problem-grid">
      <div class="problem-card animate-on-scroll">диагностика</div>
      <div class="problem-card animate-on-scroll">анализ узких мест</div>
      <div class="problem-card animate-on-scroll">настройка кеширования</div>
      <div class="problem-card animate-on-scroll">оптимизация запросов</div>
      <div class="problem-card animate-on-scroll">проверка компонентов</div>
      <div class="problem-card animate-on-scroll">настройка окружения</div>
      <div class="problem-card animate-on-scroll">контроль ошибок</div>
      <div class="problem-card animate-on-scroll">резервное копирование</div>
    </div>
  </div>
</section>

<!-- Важное разграничение -->
<section class="section">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Платформа и проекты</h2>
    </div>
    <div class="animate-on-scroll" style="max-width:720px;margin:0 auto;">
      <div style="padding:20px;background:linear-gradient(135deg, var(--accent) 0%, var(--accent-dark) 100%);border-radius:var(--card-radius);margin-bottom:16px;">
        <h3 style="font-size:1.0625rem;margin-bottom:8px;">1С-Битрикс — это платформа</h3>
        <p style="font-size:0.9375rem;line-height:1.7;margin:0;color:rgba(255,255,255,0.9);">CMS для создания корпоративных сайтов, интернет-магазинов, B2B-порталов и личных кабинетов. Подробнее о типах веб-систем — <a href="/web-systems/" style="color:#fff;font-weight:600;text-decoration:underline;">на странице веб-систем</a>.</p>
      </div>
      <div style="padding:20px;background:var(--bg-alt);border-radius:var(--card-radius);border-left:3px solid var(--primary);">
        <h3 style="font-size:1.0625rem;margin-bottom:8px;">Битрикс24 — это CRM и портал</h3>
        <p style="font-size:0.9375rem;line-height:1.7;margin:0;color:var(--text-light);">Для продаж, корпоративного портала, процессов и совместной работы. Это другой продукт, который может быть связан с веб-системами через интеграции.</p>
      </div>
    </div>
  </div>
</section>

<!-- Что создаём -->
<section class="section">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Что создаём</h2>
      <p class="section-heading__subtitle" style="max-width:640px;margin:12px auto 0;">1С-Битрикс — платформа для создания веб-систем. Подробнее о типах и сценариях — на нашей странице веб-систем</p>
    </div>
    <div style="text-align:center;margin-top:24px;" class="animate-on-scroll">
      <a href="/web-systems/" class="btn btn-accent">Типы веб-систем →</a>
    </div>
  </div>
</section>

<!-- Тарифы -->
<section class="section">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Тарифы 1С-Битрикс</h2>
      <p class="section-heading__subtitle">Подробные тарифы и цены на лицензии</p>
    </div>
    <div style="text-align:center;margin-top:24px;" class="animate-on-scroll">
      <a href="/1c-bitrix-prices/" class="btn btn-outline">Сравнить тарифы и цены</a>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="section">
  <div class="container">
    <div class="cta-section animate-on-scroll">
      <h2 class="cta-section__title">Обсудим веб-проект</h2>
      <p class="cta-section__desc">Расскажите о вашей задаче. Подберём подходящую редакцию и формат реализации.</p>
      <a href="/project/" class="btn btn-accent">Обсудить веб-проект</a>
    </div>
  </div>
</section>
</main>
<?php
require($_SERVER['DOCUMENT_ROOT'] . '/bitrix/footer.php');
