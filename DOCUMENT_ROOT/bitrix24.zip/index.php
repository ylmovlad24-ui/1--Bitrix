<?php
require($_SERVER['DOCUMENT_ROOT'] . '/bitrix/header.php');
$APPLICATION->SetTitle('Dianomi - Bitrix24, 1C-Bitrix, integracii');
?>

<main id="main-content">
<!-- 1. Hero -->
<section class="hero">
  <div class="container">
    <div class="hero__inner">
      <div class="hero__content">
        <div class="hero__badge animate-on-scroll">
          <svg viewBox="0 0 16 16" fill="none" width="16" height="16"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M5 8l2 2 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
          Авторизованный партнёр 1С-Битрикс
        </div>
        <h1 class="hero__title animate-on-scroll">
          Битрикс24, сайт и 1С работают как <span>единая система</span> — без потерь заявок, дублирования данных и ручных отчётов
        </h1>
        <p class="hero__desc animate-on-scroll">
          Запускаем Битрикс24 или сайт на 1С-Битрикс, настраиваем автоматический обмен данными с 1С.
        </p>
        <div class="hero__actions animate-on-scroll">
          <a href="/project/" class="btn btn-accent">Обсудить проект</a>
          <a href="#route" class="btn btn-outline">Посмотреть решения</a>
        </div>
        <div class="hero-stats" style="display:flex;gap:32px;justify-content:center;margin-top:48px;">
          <div class="hero-stat" style="text-align:center;">
            <div class="hero__stat-number" data-count="10" style="font-size:1.75rem;">0</div>
            <div class="hero__stat-label">лет на рынке</div>
          </div>
          <div class="hero-stat" style="text-align:center;">
            <div class="hero__stat-number" data-count="53" style="font-size:1.75rem;">0</div>
            <div class="hero__stat-label">реализованных проектов</div>
          </div>
          <div class="hero-stat" style="text-align:center;">
            <div class="hero__stat-number" style="font-size:1.75rem;">4 месяца</div>
            <div class="hero__stat-label">окупаемость проекта</div>
          </div>
        </div>
      </div>
      <div class="hero__visual animate-on-scroll">
        <div style="background:linear-gradient(135deg, #1E4474, #2A5B9A);border:1px solid rgba(42,91,154,0.6);border-radius:20px;padding:36px;box-shadow:0 8px 32px rgba(0,0,0,0.15);position:relative;overflow:hidden;">
          <h3 style="font-size:1.1875rem;font-weight:700;margin:0 0 28px;color:#fff;">Что решаем вместе:</h3>
          <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:18px;">
            <li style="display:flex;align-items:flex-start;gap:14px;padding:14px 16px;background:rgba(255,255,255,0.12);border-radius:12px;border:1px solid rgba(255,255,255,0.2);">
              <span style="flex-shrink:0;width:28px;height:28px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;">✓</span>
              <div>
                <p style="font-size:1.0625rem;color:#fff;font-weight:600;margin:0 0 4px;">Заявки с сайта <span style="color:#FFB366;">не теряются</span></p>
                <p style="font-size:0.8125rem;color:rgba(255,255,255,0.9);margin:0;">Автоматическая обработка и уведомление менеджера за 2 минуты</p>
              </div>
            </li>
            <li style="display:flex;align-items:flex-start;gap:14px;padding:14px 16px;background:rgba(255,255,255,0.12);border-radius:12px;border:1px solid rgba(255,255,255,0.2);">
              <span style="flex-shrink:0;width:28px;height:28px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;">✓</span>
              <div>
                <p style="font-size:1.0625rem;color:#fff;font-weight:600;margin:0 0 4px;">Отчёты собираются <span style="color:#FFB366;">автоматически</span></p>
                <p style="font-size:0.8125rem;color:rgba(255,255,255,0.9);margin:0;">Панель руководителя с данными в реальном времени</p>
              </div>
            </li>
            <li style="display:flex;align-items:flex-start;gap:14px;padding:14px 16px;background:rgba(255,255,255,0.12);border-radius:12px;border:1px solid rgba(255,255,255,0.2);">
              <span style="flex-shrink:0;width:28px;height:28px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;">✓</span>
              <div>
                <p style="font-size:1.0625rem;color:#fff;font-weight:600;margin:0 0 4px;">Внедряем <span style="color:#FFB366;">проектное управление</span></p>
                <p style="font-size:0.8125rem;color:rgba(255,255,255,0.9);margin:0;">Все задачи, сроки и статусы в одной системе</p>
              </div>
            </li>
            <li style="display:flex;align-items:flex-start;gap:14px;padding:14px 16px;background:rgba(255,255,255,0.12);border-radius:12px;border:1px solid rgba(255,255,255,0.2);">
              <span style="flex-shrink:0;width:28px;height:28px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px;">✓</span>
              <div>
                <p style="font-size:1.0625rem;color:#fff;font-weight:600;margin:0 0 4px;">Воронка под контролем — <span style="color:#FFB366;">каждый лид на учёте</span></p>
                <p style="font-size:0.8125rem;color:rgba(255,255,255,0.9);margin:0;">Статусы, ответственные и сроки — видите, где застревает клиент</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- 2. Узнаёте себя? -->
<section class="section section--alt">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Узнаёте себя?</h2>
      <p class="section-heading__subtitle" style="max-width:640px;margin:12px auto 0;">Если хотя бы одна из этих ситуаций про вашу компанию — пора менять систему</p>
    </div>
    <div style="max-width:960px;margin:0 auto;display:grid;grid-template-columns:repeat(2,1fr);gap:20px 32px;">
      <div style="padding:20px 24px;background:rgba(42,91,154,0.04);border-radius:12px;border-left:3px solid var(--primary);transition:all 0.3s ease;" onmouseover="this.style.boxShadow='0 4px 12px rgba(42,91,154,0.1)';this.style.transform='translateY(-1px)';" onmouseout="this.style.boxShadow='';this.style.transform='';">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
          <span style="font-size:1.25rem;">📉</span>
          <strong style="font-size:0.9375rem;color:var(--primary);">Заявки с сайта теряются</strong>
        </div>
        <p style="font-size:0.9375rem;color:var(--text-light);margin:0;line-height:1.7;">менеджер не видит обращение, клиент не получает ответ. Через неделю вы узнаете, что лид ушёл к конкурентам.</p>
      </div>
      <div style="padding:20px 24px;background:rgba(42,91,154,0.04);border-radius:12px;border-left:3px solid var(--primary);transition:all 0.3s ease;" onmouseover="this.style.boxShadow='0 4px 12px rgba(42,91,154,0.1)';this.style.transform='translateY(-1px)';" onmouseout="this.style.boxShadow='';this.style.transform='';">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
          <span style="font-size:1.25rem;">🔄</span>
          <strong style="font-size:0.9375rem;color:var(--primary);">Данные вводятся дважды</strong>
        </div>
        <p style="font-size:0.9375rem;color:var(--text-light);margin:0;line-height:1.7;">в сайт, в CRM, в учётную систему. Ошибки неизбежны, а на исправление уходит время.</p>
      </div>
      <div style="padding:20px 24px;background:rgba(42,91,154,0.04);border-radius:12px;border-left:3px solid var(--primary);transition:all 0.3s ease;" onmouseover="this.style.boxShadow='0 4px 12px rgba(42,91,154,0.1)';this.style.transform='translateY(-1px)';" onmouseout="this.style.boxShadow='';this.style.transform='';">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
          <span style="font-size:1.25rem;">🔀</span>
          <strong style="font-size:0.9375rem;color:var(--primary);">Каждый источник считает по-своему</strong>
        </div>
        <p style="font-size:0.9375rem;color:var(--text-light);margin:0;line-height:1.7;">Сайт показывает одни остатки, CRM — другие, а учётная система — третьи.</p>
      </div>
      <div style="padding:20px 24px;background:rgba(42,91,154,0.04);border-radius:12px;border-left:3px solid var(--primary);transition:all 0.3s ease;" onmouseover="this.style.boxShadow='0 4px 12px rgba(42,91,154,0.1)';this.style.transform='translateY(-1px)';" onmouseout="this.style.boxShadow='';this.style.transform='';">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
          <span style="font-size:1.25rem;">📱</span>
          <strong style="font-size:0.9375rem;color:var(--primary);">Задачи живут в Telegram и Excel</strong>
        </div>
        <p style="font-size:0.9375rem;color:var(--text-light);margin:0;line-height:1.7;">ушёл ответственный сотрудник — процесс остановился.</p>
      </div>
      <div style="padding:20px 24px;background:rgba(42,91,154,0.04);border-radius:12px;border-left:3px solid var(--primary);transition:all 0.3s ease;" onmouseover="this.style.boxShadow='0 4px 12px rgba(42,91,154,0.1)';this.style.transform='translateY(-1px)';" onmouseout="this.style.boxShadow='';this.style.transform='';">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
          <span style="font-size:1.25rem;">📊</span>
          <strong style="font-size:0.9375rem;color:var(--primary);">Выручку считаем вручную</strong>
        </div>
        <p style="font-size:0.9375rem;color:var(--text-light);margin:0;line-height:1.7;">Чтобы понять выручку за месяц, нужно собрать данные из пяти источников — и подождать несколько дней.</p>
      </div>
      <div style="padding:20px 24px;background:rgba(42,91,154,0.04);border-radius:12px;border-left:3px solid var(--primary);transition:all 0.3s ease;" onmouseover="this.style.boxShadow='0 4px 12px rgba(42,91,154,0.1)';this.style.transform='translateY(-1px)';" onmouseout="this.style.boxShadow='';this.style.transform='';">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
          <span style="font-size:1.25rem;">🎯</span>
          <strong style="font-size:0.9375rem;color:var(--primary);">Решения без данных</strong>
        </div>
        <p style="font-size:0.9375rem;color:var(--text-light);margin:0;line-height:1.7;">когда цифра становится очевидна — уже поздно.</p>
      </div>
    </div>
    <div style="text-align:center;margin-top:32px;" class="animate-on-scroll">
      <p style="font-size:1.0625rem;color:var(--text-light);margin-bottom:16px;">Знакомые проблемы? Мы решаем их комплексно — не по одной, а все вместе.</p>
      <a href="/project/" class="btn btn-accent">Обсудить проект</a>
    </div>
  </div>
</section>

<!-- 3. Выбор отправной точки -->
<section class="section" id="route">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Какая у вас задача?</h2>
      <p class="section-heading__subtitle" style="max-width:640px;margin:12px auto 0;">Выберите направление — перейдёте к подробному описанию решений</p>
    </div>
    <div class="grid grid--3" style="max-width:960px;margin:0 auto;">
      <div class="solution-card animate-on-scroll" style="border-top:4px solid var(--primary);">
        <div class="solution-card__icon">🏢</div>
        <h3 class="solution-card__title">Объединим всё в одной CRM</h3>
        <p class="solution-card__desc">Заявки теряются, данные вводятся дважды, каждый источник считает по-своему — Битрикс24 объединит всё в одной системе.</p>
        <div style="margin:12px 0;padding:12px 0;border-top:1px solid var(--border);border-bottom:1px solid var(--border);">
          <p style="font-size:0.8125rem;font-weight:600;color:var(--text-dark);margin:0 0 8px;text-transform:uppercase;letter-spacing:0.05em;">Что получите:</p>
          <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:6px;">
            <li style="font-size:0.875rem;color:var(--text-light);display:flex;align-items:flex-start;gap:6px;">
              <span style="color:var(--success);flex-shrink:0;">✓</span>
              <span>Заявки за 2 минуты попадают к менеджеру</span>
            </li>
            <li style="font-size:0.875rem;color:var(--text-light);display:flex;align-items:flex-start;gap:6px;">
              <span style="color:var(--success);flex-shrink:0;">✓</span>
              <span>Отчёты собираются автоматически</span>
            </li>
            <li style="font-size:0.875rem;color:var(--text-light);display:flex;align-items:flex-start;gap:6px;">
              <span style="color:var(--success);flex-shrink:0;">✓</span>
              <span>Все данные в одном месте</span>
            </li>
          </ul>
        </div>
        <a href="/business-systems/" class="solution-card__link">Системы управления →</a>
      </div>
      <div class="solution-card animate-on-scroll" style="border-top:4px solid var(--accent);">
        <div class="solution-card__icon">🌐</div>
        <h3 class="solution-card__title">Сайт, который работает с бизнесом</h3>
        <p class="solution-card__desc">Сайт не связан с CRM, заявки не попадают в систему — создаём сайт, который работает вместе с бизнесом.</p>
        <div style="margin:12px 0;padding:12px 0;border-top:1px solid var(--border);border-bottom:1px solid var(--border);">
          <p style="font-size:0.8125rem;font-weight:600;color:var(--text-dark);margin:0 0 8px;text-transform:uppercase;letter-spacing:0.05em;">Что получите:</p>
          <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:6px;">
            <li style="font-size:0.875rem;color:var(--text-light);display:flex;align-items:flex-start;gap:6px;">
              <span style="color:var(--success);flex-shrink:0;">✓</span>
              <span>Заявки автоматически попадают в CRM</span>
            </li>
            <li style="font-size:0.875rem;color:var(--text-light);display:flex;align-items:flex-start;gap:6px;">
              <span style="color:var(--success);flex-shrink:0;">✓</span>
              <span>Интеграция с учётной системой</span>
            </li>
            <li style="font-size:0.875rem;color:var(--text-light);display:flex;align-items:flex-start;gap:6px;">
              <span style="color:var(--success);flex-shrink:0;">✓</span>
              <span>Синхронизация товаров и цен</span>
            </li>
          </ul>
        </div>
        <a href="/web-systems/" class="solution-card__link">Веб-системы →</a>
      </div>
      <div class="solution-card animate-on-scroll" style="border-top:4px solid var(--success);">
        <div class="solution-card__icon">🔧</div>
        <h3 class="solution-card__title">Наведём порядок в системе</h3>
        <p class="solution-card__desc">Всё есть, но процессы тормозят, задачи живут в Telegram, а отчёты собираются вручную — наведём порядок.</p>
        <div style="margin:12px 0;padding:12px 0;border-top:1px solid var(--border);border-bottom:1px solid var(--border);">
          <p style="font-size:0.8125rem;font-weight:600;color:var(--text-dark);margin:0 0 8px;text-transform:uppercase;letter-spacing:0.05em;">Что получите:</p>
          <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:6px;">
            <li style="font-size:0.875rem;color:var(--text-light);display:flex;align-items:flex-start;gap:6px;">
              <span style="color:var(--success);flex-shrink:0;">✓</span>
              <span>Прозрачные процессы и задачи</span>
            </li>
            <li style="font-size:0.875rem;color:var(--text-light);display:flex;align-items:flex-start;gap:6px;">
              <span style="color:var(--success);flex-shrink:0;">✓</span>
              <span>Автоматические отчёты в реальном времени</span>
            </li>
            <li style="font-size:0.875rem;color:var(--text-light);display:flex;align-items:flex-start;gap:6px;">
              <span style="color:var(--success);flex-shrink:0;">✓</span>
              <span>Система работает без ручного ввода</span>
            </li>
          </ul>
        </div>
        <a href="/approach/" class="solution-card__link">Аудит и оптимизация →</a>
      </div>
    </div>
  </div>
</section>

<!-- 4. Результаты (до/после) -->
<section class="section">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Как изменится работа после проекта</h2>
    </div>
    <div style="max-width:960px;margin:0 auto;">
      <div style="display:flex;gap:0;position:relative;overflow:hidden;border-radius:16px;border:1px solid var(--border);box-shadow:var(--shadow-md);">
        <!-- До -->
        <div style="background:linear-gradient(to right, rgba(231,76,60,0.04), transparent 60%);padding:40px 32px;flex:1;border-right:1px solid var(--border);">
          <h3 style="font-size:0.8125rem;font-weight:600;margin:0 0 28px;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-muted);">До проекта</h3>
          <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:18px;">
            <li style="font-size:0.9375rem;line-height:1.6;color:var(--text-light);">Данные находятся в разных системах</li>
            <li style="font-size:0.9375rem;line-height:1.6;color:var(--text-light);">Заявки распределяются вручную</li>
            <li style="font-size:0.9375rem;line-height:1.6;color:var(--text-light);">Отчёты собираются в таблицах</li>
            <li style="font-size:0.9375rem;line-height:1.6;color:var(--text-light);">Задачи контролируются через сообщения</li>
            <li style="font-size:0.9375rem;line-height:1.6;color:var(--text-light);">Нет единой картины бизнеса</li>
          </ul>
        </div>
        <!-- Разделитель -->
        <div style="width:1px;background:var(--border);position:relative;flex-shrink:0;">
          <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:24px;height:24px;border-radius:50%;background:var(--bg-alt);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:12px;color:var(--text-muted);">→</div>
        </div>
        <!-- После -->
        <div style="background:linear-gradient(to right, rgba(39,174,96,0.03), transparent 40%), #fff;padding:40px 32px;flex:1;">
          <h3 style="font-size:0.8125rem;font-weight:600;margin:0 0 28px;text-transform:uppercase;letter-spacing:0.08em;color:var(--accent);">После проекта</h3>
          <ul style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:18px;">
            <li style="display:flex;align-items:flex-start;gap:12px;font-size:0.9375rem;line-height:1.6;color:var(--text-dark);">
              <span style="flex-shrink:0;width:20px;height:20px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;margin-top:1px;">✓</span>
              <span>Единый контур с понятными правилами обмена</span>
            </li>
            <li style="display:flex;align-items:flex-start;gap:12px;font-size:0.9375rem;line-height:1.6;color:var(--text-dark);">
              <span style="flex-shrink:0;width:20px;height:20px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;margin-top:1px;">✓</span>
              <span>Заявки автоматически попадают к менеджеру</span>
            </li>
            <li style="display:flex;align-items:flex-start;gap:12px;font-size:0.9375rem;line-height:1.6;color:var(--text-dark);">
              <span style="flex-shrink:0;width:20px;height:20px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;margin-top:1px;">✓</span>
              <span>Панель руководителя в реальном времени</span>
            </li>
            <li style="display:flex;align-items:flex-start;gap:12px;font-size:0.9375rem;line-height:1.6;color:var(--text-dark);">
              <span style="flex-shrink:0;width:20px;height:20px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;margin-top:1px;">✓</span>
              <span>Все задачи, сроки и статусы — в системе</span>
            </li>
            <li style="display:flex;align-items:flex-start;gap:12px;font-size:0.9375rem;line-height:1.6;color:var(--text-dark);">
              <span style="flex-shrink:0;width:20px;height:20px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;margin-top:1px;">✓</span>
              <span>Управленческая аналитика доступна в любой момент</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- 5. Наш подход -->
<section class="section section--alt">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Наш подход: от картины к деталям</h2>
    </div>
    <div style="max-width:960px;margin:0 auto;display:grid;grid-template-columns:repeat(3,1fr);gap:24px;">
      <div style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:24px;box-shadow:var(--shadow-sm);transition:all 0.3s ease;border-top:3px solid var(--accent);" onmouseover="this.style.boxShadow='var(--shadow-lg)';this.style.transform='translateY(-2px)';this.style.borderColor='var(--primary)';" onmouseout="this.style.boxShadow='var(--shadow-sm)';this.style.transform='';this.style.borderColor='var(--border)';">
        <div style="width:40px;height:40px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.125rem;font-weight:700;margin-bottom:16px;">1</div>
        <h4 style="font-size:1rem;font-weight:600;margin:0;line-height:1.4;">Выясняем, что болит, и что считаем успешным</h4>
      </div>
      <div style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:24px;box-shadow:var(--shadow-sm);transition:all 0.3s ease;border-top:3px solid var(--accent);" onmouseover="this.style.boxShadow='var(--shadow-lg)';this.style.transform='translateY(-2px)';this.style.borderColor='var(--primary)';" onmouseout="this.style.boxShadow='var(--shadow-sm)';this.style.transform='';this.style.borderColor='var(--border)';">
        <div style="width:40px;height:40px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.125rem;font-weight:700;margin-bottom:16px;">2</div>
        <h4 style="font-size:1rem;font-weight:600;margin:0;line-height:1.4;">Собираем карту текущих процессов и систем</h4>
      </div>
      <div style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:24px;box-shadow:var(--shadow-sm);transition:all 0.3s ease;border-top:3px solid var(--accent);" onmouseover="this.style.boxShadow='var(--shadow-lg)';this.style.transform='translateY(-2px)';this.style.borderColor='var(--primary)';" onmouseout="this.style.boxShadow='var(--shadow-sm)';this.style.transform='';this.style.borderColor='var(--border)';">
        <div style="width:40px;height:40px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.125rem;font-weight:700;margin-bottom:16px;">3</div>
        <h4 style="font-size:1rem;font-weight:600;margin:0;line-height:1.4;">Рисуем, как система будет работать после</h4>
      </div>
      <div style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:24px;box-shadow:var(--shadow-sm);transition:all 0.3s ease;border-top:3px solid var(--accent);" onmouseover="this.style.boxShadow='var(--shadow-lg)';this.style.transform='translateY(-2px)';this.style.borderColor='var(--primary)';" onmouseout="this.style.boxShadow='var(--shadow-sm)';this.style.transform='';this.style.borderColor='var(--border)';">
        <div style="width:40px;height:40px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.125rem;font-weight:700;margin-bottom:16px;">4</div>
        <h4 style="font-size:1rem;font-weight:600;margin:0;line-height:1.4;">Разбиваем на этапы, чтобы видеть результат сразу</h4>
      </div>
      <div style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:24px;box-shadow:var(--shadow-sm);transition:all 0.3s ease;border-top:3px solid var(--accent);" onmouseover="this.style.boxShadow='var(--shadow-lg)';this.style.transform='translateY(-2px)';this.style.borderColor='var(--primary)';" onmouseout="this.style.boxShadow='var(--shadow-sm)';this.style.transform='';this.style.borderColor='var(--border)';">
        <div style="width:40px;height:40px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.125rem;font-weight:700;margin-bottom:16px;">5</div>
        <h4 style="font-size:1rem;font-weight:600;margin:0;line-height:1.4;">Реализуем и подключаем каждый контур</h4>
      </div>
      <div style="background:#fff;border:1px solid var(--border);border-radius:12px;padding:24px;box-shadow:var(--shadow-sm);transition:all 0.3s ease;border-top:3px solid var(--accent);" onmouseover="this.style.boxShadow='var(--shadow-lg)';this.style.transform='translateY(-2px)';this.style.borderColor='var(--primary)';" onmouseout="this.style.boxShadow='var(--shadow-sm)';this.style.transform='';this.style.borderColor='var(--border)';">
        <div style="width:40px;height:40px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.125rem;font-weight:700;margin-bottom:16px;">6</div>
        <h4 style="font-size:1rem;font-weight:600;margin:0;line-height:1.4;">Проверяем, запускаем и остаёмся на поддержке</h4>
      </div>
    </div>
    <div style="text-align:center;margin-top:24px;" class="animate-on-scroll">
      <a href="/approach/" class="btn btn-outline">Как мы работаем</a>
    </div>
  </div>
</section>

<!-- 6. О Dianomi -->
<section class="section">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">О Dianomi</h2>
    </div>
    <div style="max-width:720px;margin:0 auto 32px;" class="animate-on-scroll">
      <p style="font-size:1.0625rem;color:var(--text-light);line-height:1.8;margin-bottom:24px;">
        Dianomi — это команда архитекторов, разработчиков и внедренцев. Мы не просто настраиваем Битрикс24 или делаем сайт — мы проектируем систему, в которой всё связано: сайт общается с CRM, CRM — с 1С, а вы видите результат в управленческой панели.
      </p>
      <p style="font-size:1.0625rem;color:var(--text-light);line-height:1.8;margin-bottom:24px;" class="animate-on-scroll">
        Офис в Барнауле. Работаем с бизнесом по всей России.
      </p>
    </div>
    <div class="grid grid--2" style="max-width:720px;margin:0 auto;">
      <div class="solution-card animate-on-scroll">
        <h3 style="font-size:1rem;margin-bottom:8px;">Проектируем систему целиком</h3>
        <p class="solution-card__desc">Не отдельные функции, а архитектура, в которой всё связано.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <h3 style="font-size:1rem;margin-bottom:8px;">Работаем прозрачно</h3>
        <p class="solution-card__desc">Не публикуем вымышленные кейсы и цифры.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <h3 style="font-size:1rem;margin-bottom:8px;">Данные вместе с процессом</h3>
        <p class="solution-card__desc">Проектируем правила движения данных и интеграций.</p>
      </div>
      <div class="solution-card animate-on-scroll">
        <h3 style="font-size:1rem;margin-bottom:8px;">Сопровождаем после запуска</h3>
        <p class="solution-card__desc">Поддержка, развитие процессов и новые интеграции.</p>
      </div>
    </div>
  </div>
</section>

<!-- 7. FAQ -->
<section class="section section--alt">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Частые вопросы</h2>
    </div>
    <div class="faq-list animate-on-scroll">
      <div class="faq-item">
        <button class="faq-question" onclick="this.parentElement.classList.toggle('faq-item--open')">
          <span>Сколько времени занимает внедрение Битрикс24?</span>
          <span class="faq-question__icon">+</span>
        </button>
        <div class="faq-answer"><p class="faq-answer__text">Простой запуск CRM — от 2 недель. Комплексное внедрение с интеграцией сайта, 1С и бизнес-процессами — от 2 месяцев. Точные сроки определяем после обследования.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-question" onclick="this.parentElement.classList.toggle('faq-item--open')">
          <span>Чем коробочный Битрикс24 отличается от облачного?</span>
          <span class="faq-question__icon">+</span>
        </button>
        <div class="faq-answer"><p class="faq-answer__text">Облачный — вы получаете готовую систему, которую настраиваем под вас. Размещается на серверах Битрикс24. Коробочный — устанавливается на ваш сервер, даёт полный доступ к коду и возможность глубокой кастомизации. Выбираем вместе, исходя из ваших задач и требований к данным.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-question" onclick="this.parentElement.classList.toggle('faq-item--open')">
          <span>Можно ли интегрировать 1С-Битрикс с Битрикс24?</span>
          <span class="faq-question__icon">+</span>
        </button>
        <div class="faq-answer"><p class="faq-answer__text">Да, это одна из основных задач. Настраиваем двусторонний обмен данными между сайтом и CRM.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-question" onclick="this.parentElement.classList.toggle('faq-item--open')">
          <span>Как происходит перенос данных из другой системы?</span>
          <span class="faq-question__icon">+</span>
        </button>
        <div class="faq-answer"><p class="faq-answer__text">Изучаем данные, проектируем структуру, тестируем на тестовом контуре и запускаем миграцию.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-question" onclick="this.parentElement.classList.toggle('faq-item--open')">
          <span>Что входит в сопровождение после запуска?</span>
          <span class="faq-question__icon">+</span>
        </button>
        <div class="faq-answer"><p class="faq-answer__text">Поддержка пользователей, контроль интеграций, исправления и плановое развитие системы.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-question" onclick="this.parentElement.classList.toggle('faq-item--open')">
          <span>Работаете ли вы с регионами?</span>
          <span class="faq-question__icon">+</span>
        </button>
        <div class="faq-answer"><p class="faq-answer__text">Да, большая часть проектов реализуется дистанционно. Офис в Барнауле, но мы регулярно работаем с клиентами из Москвы, Новосибирска, Красноярска и других городов. Онлайн-встречи, документооборот и передача данных — всё в цифре.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-question" onclick="this.parentElement.classList.toggle('faq-item--open')">
          <span>Как понять, какой формат работы нам нужен?</span>
          <span class="faq-question__icon">+</span>
        </button>
        <div class="faq-answer"><p class="faq-answer__text">На встрече обсуждаем задачу и предлагаем подходящий формат: обследование, внедрение, аудит или сопровождение.</p></div>
      </div>
      <div class="faq-item">
        <button class="faq-question" onclick="this.parentElement.classList.toggle('faq-item--open')">
          <span>Можно ли начать с аудита текущей системы?</span>
          <span class="faq-question__icon">+</span>
        </button>
        <div class="faq-answer"><p class="faq-answer__text">Да, аудит — отличный старт. Выявим проблемы и предложим поэтапный план развития.</p></div>
      </div>
    </div>
  </div>
</section>

<!-- 8. CTA с формой -->
<section class="section">
  <div class="container">
    <div class="cta-section animate-on-scroll">
      <h2 class="cta-section__title">Расскажите о задаче — предложим решение</h2>
      <p class="cta-section__desc">Заполните форму — свяжемся в течение рабочего дня, зададим несколько вопросов и предложим формат работы.</p>
      <form id="ctaForm" onsubmit="return handleFormSubmit(event)" style="max-width:480px;margin:24px auto 0;text-align:left;">
        <div class="form-group">
          <input type="text" name="name" class="form-control" placeholder="Имя" required>
        </div>
        <div class="form-group">
          <input type="tel" name="phone" class="form-control" placeholder="Телефон" required>
        </div>
        <div class="form-group">
          <textarea name="message" class="form-control" placeholder="Опишите задачу" rows="3"></textarea>
        </div>
        <button type="submit" class="btn btn-accent btn-full">Отправить</button>
      </form>
      <p style="text-align:center;font-size:0.875rem;color:var(--text-muted);margin-top:16px;" class="animate-on-scroll">
        Или напишите нам в Telegram — ответим быстрее: <a href="https://t.me/dianomi" style="color:var(--accent);" target="_blank" rel="noopener">@dianomi</a>
      </p>
    </div>
  </div>
</section>
</main>
<?php
require($_SERVER['DOCUMENT_ROOT'] . '/bitrix/footer.php');
