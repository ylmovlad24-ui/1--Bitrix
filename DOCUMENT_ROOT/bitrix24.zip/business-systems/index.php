<?php
require($_SERVER['DOCUMENT_ROOT'] . '/bitrix/header.php');
$APPLICATION->SetTitle('Systemsy upravlenija');
?>

<main id="main-content">
<!-- Breadcrumb -->
<div class="breadcrumbs">
  <div class="container">
    <ul class="breadcrumbs__list">
      <li><a href="/index.php">Главная</a></li>
      <li class="breadcrumbs__separator">/</li>
      <li><a href="/business-systems/">Решения</a></li>
      <li class="breadcrumbs__separator">/</li>
      <li class="breadcrumbs__current">Системы управления бизнесом</li>
    </ul>
  </div>
</div>

<!-- Page Hero -->
<section class="page-hero">
  <div class="container">
    <h1 class="page-hero__title">Системы управления бизнесом на базе Битрикс24</h1>
    <p class="page-hero__subtitle">Объединяем продажи, внутренние процессы, задачи, проекты и коммуникации в общей рабочей системе.</p>
    <div style="margin-top:24px;">
      <a href="/project/" class="btn btn-accent">Обсудить внедрение</a>
    </div>
  </div>
</section>

<!-- Когда нужна система -->
<section class="section" id="problems">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Когда нужна система</h2>
      <p class="section-heading__subtitle">Если хотя бы один пункт про вас — пора систематизировать</p>
    </div>
    <div class="grid grid--4">
      <div class="problem-card animate-on-scroll">Обращения теряются</div>
      <div class="problem-card animate-on-scroll">Сделки ведутся без единого стандарта</div>
      <div class="problem-card animate-on-scroll">Задачи распределяются в чатах</div>
      <div class="problem-card animate-on-scroll">Согласования затягиваются</div>
      <div class="problem-card animate-on-scroll">Ответственность размыта</div>
      <div class="problem-card animate-on-scroll">Руководитель не видит загрузку и статус работы</div>
      <div class="problem-card animate-on-scroll">Действующий Битрикс24 используется частично</div>
    </div>
  </div>
</section>

<!-- Что можно организовать -->
<section class="section section--alt" id="solutions">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Что можно организовать</h2>
      <p class="section-heading__subtitle">Платформа Битрикс24 покрывает все ключевые направления работы компании</p>
    </div>
    <div class="grid grid--4">
      <!-- CRM и продажи -->
      <div class="platform-card animate-on-scroll">
        <div class="platform-card__header">
          <div class="platform-card__icon platform-card__icon--bx">💬</div>
          <h3 class="platform-card__title">CRM и продажи</h3>
        </div>
        <p style="font-size:0.875rem;color:var(--text-light);margin-bottom:12px;">Заявки не теряются, продажи под контролем</p>
        <ul class="platform-card__list">
          <li>Воронки продаж и автоматизация</li>
          <li>Распределение клиентов</li>
          <li>Контроль каждой сделки</li>
          <li>История всех коммуникаций</li>
          <li>Автоматические уведомления</li>
          <li>Отчёты по эффективности</li>
        </ul>
      </div>
      <!-- Корпоративный портал -->
      <div class="platform-card animate-on-scroll">
        <div class="platform-card__header">
          <div class="platform-card__icon platform-card__icon--bx">🏢</div>
          <h3 class="platform-card__title">Корпоративный портал</h3>
        </div>
        <p style="font-size:0.875rem;color:var(--text-light);margin-bottom:12px;">Процессы автоматизированы, сотрудники работают слаженно</p>
        <ul class="platform-card__list">
          <li>Структура компании и отделы</li>
          <li>Рабочие группы и проекты</li>
          <li>База знаний и документы</li>
          <li>Внутренние объявления</li>
          <li>Сервисы для сотрудников</li>
          <li>Единое рабочее пространство</li>
        </ul>
      </div>
      <!-- Бизнес-процессы -->
      <div class="platform-card animate-on-scroll">
        <div class="platform-card__header">
          <div class="platform-card__icon platform-card__icon--bx">⚙️</div>
          <h3 class="platform-card__title">Бизнес-процессы</h3>
        </div>
        <p style="font-size:0.875rem;color:var(--text-light);margin-bottom:12px;">Согласования за минуты, а не дни</p>
        <ul class="platform-card__list">
          <li>Согласование документов</li>
          <li>Автоматическая обработка заявок</li>
          <li>Постановка задач по правилам</li>
          <li>Уведомления и напоминания</li>
          <li>Контроль сроков исполнения</li>
          <li>Маршруты процессов</li>
        </ul>
      </div>
      <!-- Задачи и проекты -->
      <div class="platform-card animate-on-scroll">
        <div class="platform-card__header">
          <div class="platform-card__icon platform-card__icon--bx">📋</div>
          <h3 class="platform-card__title">Задачи и проекты</h3>
        </div>
        <p style="font-size:0.875rem;color:var(--text-light);margin-bottom:12px;">Все задачи в системе, сроки под контролем</p>
        <ul class="platform-card__list">
          <li>Шаблоны проектов</li>
          <li>Роли и ответственность</li>
          <li>Этапы и сроки исполнения</li>
          <li>Зависимости между задачами</li>
          <li>Отчётность и аналитика</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- Платформа -->
<section class="section">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Платформа</h2>
    </div>
    <div class="animate-on-scroll" style="max-width:720px;margin:0 auto;text-align:center;font-size:1.0625rem;color:var(--text-light);line-height:1.8;">
      <p>Все решения реализуются на платформе <a href="/bitrix24/" style="color:var(--primary);font-weight:600;">Битрикс24</a> — облачная или коробочная версия, в зависимости от требований к безопасности и инфраструктуре.</p>
      <div style="margin-top:20px;">
        <a href="/bitrix24/" class="btn btn-outline">Подробнее о Битрикс24 →</a>
      </div>
    </div>
  </div>
</section>

<!-- CTA Section -->
<section class="section section--alt">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Сценарии проекта</h2>
    </div>
    <div class="animate-on-scroll" style="max-width:720px;margin:0 auto;">
      <ul style="list-style:none;padding:0;margin:0;display:grid;gap:12px;">
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--primary);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">Внедрение с нуля</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--primary);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">Аудит и перезапуск</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--primary);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">Развитие существующего портала</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--primary);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">Миграция из другой CRM</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--primary);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">Переход из облака в коробку</li>
        <li style="padding:14px 16px;background:var(--bg-alt);border-left:3px solid var(--primary);border-radius:0 var(--card-radius) var(--card-radius) 0;font-size:0.9375rem;color:var(--text-light);">Сопровождение</li>
      </ul>
    </div>
  </div>
</section>

<!-- Этапы -->
<section class="section" id="stages">
  <div class="container">
    <div class="section-heading animate-on-scroll">
      <h2 class="section-heading__title">Этапы</h2>
    </div>
    <div class="animate-on-scroll" style="max-width:720px;margin:0 auto;">
      <div class="process-steps">
        <div class="process-step">
          <div class="process-step__number">1</div>
          <div class="process-step__content">
            <h4>Обследование</h4>
            <p>Изучаем текущие процессы, выявляем проблемы и точки роста</p>
          </div>
        </div>
        <div class="process-step">
          <div class="process-step__number">2</div>
          <div class="process-step__content">
            <h4>Проектирование</h4>
            <p>Проектируем архитектуру системы и сценарии использования</p>
          </div>
        </div>
        <div class="process-step">
          <div class="process-step__number">3</div>
          <div class="process-step__content">
            <h4>Настройка и разработка</h4>
            <p>Настраиваем модули, разрабатываем кастомные решения</p>
          </div>
        </div>
        <div class="process-step">
          <div class="process-step__number">4</div>
          <div class="process-step__content">
            <h4>Интеграция</h4>
            <p>Связываем с учётными системами, сайтами, коммуникациями</p>
          </div>
        </div>
        <div class="process-step">
          <div class="process-step__number">5</div>
          <div class="process-step__content">
            <h4>Тестирование</h4>
            <p>Проверяем сценарии, устраняем ошибки, оптимизируем</p>
          </div>
        </div>
        <div class="process-step">
          <div class="process-step__number">6</div>
          <div class="process-step__content">
            <h4>Обучение</h4>
            <p>Обучаем команду, готовим документацию</p>
          </div>
        </div>
        <div class="process-step">
          <div class="process-step__number">7</div>
          <div class="process-step__content">
            <h4>Запуск</h4>
            <p>Выводим систему в эксплуатацию, мониторим первые недели</p>
          </div>
        </div>
        <div class="process-step">
          <div class="process-step__number">8</div>
          <div class="process-step__content">
            <h4>Развитие</h4>
            <p>Дорабатываем, расширяем, масштабируем по мере роста</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA Section -->
<section class="section section--alt">
  <div class="container">
    <div class="cta-section animate-on-scroll">
      <h2 class="cta-section__title">Обсудить систему управления компанией</h2>
      <p class="cta-section__desc">Расскажем, как Битрикс24 может решить ваши задачи — с примерами и прогнозом по цифрам.</p>
      <a href="/project/" class="btn btn-accent">Обсудить внедрение</a>
    </div>
  </div>
</section>

<!-- Sticky CTA (mobile only) -->
<div class="sticky-cta" id="stickyCta">
  <a href="tel:+738520000000" class="btn btn-primary">📞 Позвонить</a>
  <a href="/project/" class="btn btn-accent">Заявка</a>
</div>
</main>
<?php
require($_SERVER['DOCUMENT_ROOT'] . '/bitrix/footer.php');
